#include<stdio.h>
#include<math.h>
#include<graphics.h>
#define Max 100
void BzCurve(int x[Max], int y[Max])
{
    int i;
    float t;
    int xt, yt;
 
    for (t = 0.0; t < 1.0; t += 0.0005) 
    {
        xt = pow(1 - t, 3) * x[0] + 3 * t * pow(1 - t, 2) * x[1] + 3 * pow(t, 2) * (1 - t) * x[2] + pow(t, 3) * x[3];
        yt = pow(1 - t, 3) * y[0] + 3 * t * pow(1 - t, 2) * y[1] + 3 * pow(t, 2) * (1 - t) * y[2] + pow(t, 3) * y[3];
        putpixel(xt, yt, WHITE);
    }
}
 
void Triad_kochcurve(int x1, int y1, int x2, int y2, int n)
{
    int x3, y3, x4, y4, x5, y5;
 
    if (n == 0) 
    {
        line(x1, y1, x2, y2);
    }
    else 
    {
        x3 = (2 * x1 + x2) / 3;
        y3 = (2 * y1 + y2) / 3;
        x4 = (x1 + x2) / 2 - (int)((y2 - y1) * sqrt(3) / 6);
        y4 = (y1 + y2) / 2 + (int)((x2 - x1) * sqrt(3) / 6);
        x5 = (2 * x2 + x1) / 3;
        y5 = (2 * y2 + y1) / 3;
        Triad_kochcurve(x1, y1, x3, y3, n - 1);
	Triad_kochcurve(x3, y3, x4, y4, n - 1);
	Triad_kochcurve(x4, y4, x5, y5, n - 1);
	Triad_kochcurve(x5, y5, x2, y2, n - 1);
    }
}



void Fractal(int x1, int y1, int x2, int y2, int n)
{
    int x, y;
    if (n == 0)
    {
	line(x1, y1, x2, y2);
    }
    else
    {
	x = (x1 + x2) / 2 + (y2 - y1) / 2;
	y = (y1 + y2) / 2 - (x2 - x1) / 2;

	Fractal(x1, y1, x, y, n - 1);
	Fractal(x, y, x2, y2, n - 1);
    }
}
// void Fractal(int x1, int y1, int x2, int y2, int n)
// {
//     int i;
//     int x3, y3, x4, y4, x5, y5;

//     if (n == 0) 
//     {
//         line(x1, y1, x2, y2);
//     }

//     else 
//     {
//         for (i = 0; i < n; i++)
//         {
//             x3 = (2 * x1 + x2) / 3;
//             y3 = (2 * y1 + y2) / 3;
//             x4 = (x1 + x2) / 2;
//             y4 = (y1 + y2) / 2;
//             x5 = (x1 + 2 * x2) / 3;
//             y5 = (y1 + 2 * y2) / 3;

//             line(x1, y1, x3, y3);
//             line(x3, y3, x4, y4);
//             line(x4, y4, x5, y5);
//             line(x5, y5, x2, y2);

//             x1 = x3;
//             y1 = y3;
//             x2 = x5;
//             y2 = y5;
//         }
//     }
// }

void main()
{
    int gd = DETECT,gm;
    int x[Max],y[Max],n;
    int option,i;
    clrscr();

    do{
        printf("\n\n\t\tMENU\n 1.Four point Bezier curve\n 2. Triadic Koch Curve\n 3. Fractal Line\n 4. Code Exited");

        printf("\nEnter Option : ");
        scanf("%d",&option);

        switch (option)
        {
            case 1: 
            printf("Performing Four point Bezier curve \n");
            printf("Enter four control points:\n");
            for (i = 0; i < 4; i++) 
            {
                scanf("%d%d", &x[i], &y[i]);
            }
            initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
            BzCurve(x, y);
            getch();
            closegraph();
            
            break;

            case 2: 
            printf("Enter the starting and ending coordinates of the line:\n");
            scanf("%d %d %d %d", &x[0], &y[0], &x[1], &y[1]);
            printf("Enter the number of iterations:\n");
            scanf("%d", &n);
            printf("Performing Triadic Koch Curve \n");
            initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
            Triad_kochcurve(x[0], y[0], x[1], y[1], n);
            getch();
            closegraph();
            break;

            case 3: 
            printf("Enter the starting and ending coordinates of the line:\n");
            scanf("%d %d %d %d",&x[0] ,&y[0] ,&x[1] ,&y[1]);
            printf("Enter the number of iterations:\n");
            scanf("%d", &n);

            printf("Performing Fractal Line. \n");
            initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
            Fractal(x[0], y[0], x[1], y[1], n);
            getch();
            closegraph();
            break;

            case 4: 
            printf("Code Exited \n");
            break;
        
            default:
            printf("Enter Proper option !? \n");
            break;
        }

    }while(option!=4);

}