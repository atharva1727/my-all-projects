#include<stdio.h>
#include<graphics.h>
#include<conio.h>
#include<math.h>

void koch(int x1, int y1, int x2, int y2, int lvl)
{
   if(lvl == 0)
   {
      line(x1, y1, x2, y2);
      return;
   }

   int dX = x2 - x1;
   int dY = y2 - y1;

   int x3 = x1 + (dX/3);
   int y3 = y1 + (dY/3);

   int x4 = x1 + (dX*2)/3;
   int y4 = y1 + (dY*2)/3;

   //int angle = 60 * (M_PI/180);

   int x5 = x3 + (x4 - x3) * cos(M_PI / 3) - (y4 - y3) * sin(M_PI / 3);
   int y5 = y3 + (x4 - x3) * sin(M_PI / 3) + (y4 - y3) * cos(M_PI / 3);

   koch(x1, y1, x3, y3, lvl - 1);
   koch(x3, y3, x5, y5, lvl - 1);
   koch(x5, y5, x4, y4, lvl - 1);
   koch(x4, y4, x2, y2, lvl - 1);
}

void main()
{
   int gd = DETECT, gm;
   initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
   //line(100, 100, 300, 100);
   //getch();
   koch(100, 300, 500, 300, 8);
   getch();
   closegraph();
}